
-- Initialize screen
screen:clear()
screen:flip()
-- Player variables
player = {
    x = 240,
    y = 240,
    speed = 3,
    width = 32,
    height = 32
}

-- Bullet variables
bullets = {}
bulletSpeed = 5

-- Enemy variables
enemies = {}
enemySpeed = 2
enemySpawnTimer = 0
enemySpawnDelay = 60

-- Game state
score = 0
gameOver = false

-- Load images (replace with your own images or use placeholders)
playerImage = Image.load ("player.png") -- 32x32 image
bulletImage = Image.load ("bullet.png") -- 8x16 image
enemyImage = Image.load ("enemy.png")   -- 32x32 image

-- Function to draw the player
function drawPlayer()
    screen:blit(player.x, player.y , playerImage)
end

-- Function to draw bullets
function drawBullets()
    for i, bullet in ipairs(bullets) do
        screen:blit(bullet.x, bullet.y, bulletImage)
    end
end

-- Function to draw enemies
function drawEnemies()
    for i, enemy in ipairs(enemies) do
        screen:blit(enemy.x, enemy.y, enemyImage)
    end
end

-- Function to update bullets
function updateBullets()
    for i = #bullets, 1, -1 do
        bullets[i].y = bullets[i].y - bulletSpeed
        if bullets[i].y < 0 then
            table.remove(bullets, i)
        end
    end
end

-- Function to update enemies
function updateEnemies()
    for i = #enemies, 1, -1 do
        enemies[i].y = enemies[i].y + enemySpeed
        if enemies[i].y > screen:height() then
            table.remove(enemies, i)
        end
    end
end

-- Function to check collisions
function checkCollisions()
    for i, enemy in ipairs(enemies) do
        for j, bullet in ipairs(bullets) do
            if bullet.x < enemy.x + 32 and
               bullet.x + 8 > enemy.x and
               bullet.y < enemy.y + 32 and
               bullet.y + 16 > enemy.y then
                table.remove(enemies, i)
                table.remove(bullets, j)
                score = score + 1
                break
            end
        end
        if player.x < enemy.x + 32 and
           player.x + 32 > enemy.x and
           player.y < enemy.y + 32 and
           player.y + 32 > enemy.y then
            gameOver = true
        end
    end
end

-- Main game loop
while not gameOver do
    screen:clear()
          Pad = Controls.read()
    -- Handle input
    if Pad:left() then
        player.x = player.x - player.speed
    end
    if Pad:right() then
        player.x = player.x + player.speed
    end
    if Pad:cross() then
        table.insert(bullets, {x = player.x + 12, y = player.y})
    end

    -- Spawn enemies
    enemySpawnTimer = enemySpawnTimer + 1
    if enemySpawnTimer >= enemySpawnDelay then
        table.insert(enemies, {x = math.random(0, screen:width() - 32), y = -32})
        enemySpawnTimer = 0
    end

    -- Update game objects
    updateBullets()
    updateEnemies()
    checkCollisions()

    -- Draw game objects
    drawPlayer()
    drawBullets()
    drawEnemies()

    -- Draw score
    screen:print(10, 10, "Score: " .. score)

    -- Render frame
    screen:flip()
end

-- Game over screen
screen:clear()
screen:print(200, 200, "Game Over!")
screen:print(200, 220, "Final Score: " .. score)
screen:flip()

-- Wait for a few seconds before exiting
for i = 1, 180 do
    screen:flip()
end
